
#include <iostream>

int main() { std::cout << "protobuf test" << std::endl; }